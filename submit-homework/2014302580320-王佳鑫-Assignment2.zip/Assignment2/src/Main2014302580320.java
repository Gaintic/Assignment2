import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import org.jsoup.select.Elements;

public class Main2014302580320 {
	public static void main(String args[]) throws IOException{
		String urlString="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Sanbao%20Zhang";   
		String filePath="teacher.html";                
		
		HttpRequest response=HttpRequest.get(urlString);
		response.receive(new File(filePath));              
		
		File inputFile = new File("teacher.html");
		FileWriter txt = new FileWriter("teacher.txt");
		Document doc = Jsoup.parse(inputFile, "UTF-8");
		
		Elements name = doc.select("h3");
		String n = name.text();
		txt.write(n+"\r\n");
		
		Elements all = doc.select("p");
		for(int i=0;i<all.size();i++){
			String s = all.get(i).text();
			txt.write(s+"\r\n");
		}
		
		txt.write("\r\n"+"�����������ʽ��ȡ�绰��������䣺"+"\r\n");
		
		Elements phone = doc.select("P:matchesOwn(\\d{3}-\\d{4}-\\d{4})");
		String p = phone.text();
		String[] ph = p.split(" ");
		txt.write(ph[6]+"\r\n");
		
		Elements mailbox = doc.select("p:matchesOwn(\\w{5}@\\w{3}\\.\\w{3}\\.\\w{2})");
		String m = mailbox.text();
		String[] ma = m.split(" ");
		txt.write(ma[8]+"\r\n");
		

		txt.close();
	}
}

