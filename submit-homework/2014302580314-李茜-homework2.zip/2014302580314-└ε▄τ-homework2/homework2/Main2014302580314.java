package homework2;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580314 {


	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//����һ��url����document����
		String url="http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen%20Sheng%20Li";
		Document doc=Jsoup.connect(url).get();    
		//��ȡh3��ǩ�µ�����
		Elements elements1=doc.select("h3.title");
		//��ȡ���������绰���ڵ���Ϣ
		Elements elements2=doc.select("p:matchesOwn((\\w+@\\w+(\\.\\w+){1,2})|(\\d+{3}-?\\d{8}))");
		//��ȡ������ϸ��Ϣ
		Elements elements3=doc.select("p:contains(�ֱ�)");
		
		//��ȡԪ������
		String name=elements1.text();                           
		String simpleMess=elements2.text();                  
		String introduc=elements3.text();
	    
		//�ָ��ַ���
		String patternString=" ";
		Pattern pattern=Pattern.compile(patternString);
		String[] simpleMessSpilt=pattern.split(simpleMess);
		String newline="\r\n";                             //���е��ַ���      
		
		//���txt
		File file=new File("homepageMess.txt");
		FileWriter fw=null;
		if(!file.exists()){
			file.createNewFile();
			fw=new FileWriter(file);
		}
		BufferedWriter out=new BufferedWriter(fw);
		out.write(name,0,name.length());
		out.write(newline,0,newline.length());
		for(int i=0;i<simpleMessSpilt.length;i++){
		out.write(simpleMessSpilt[i],0,simpleMessSpilt[i].length());
		out.write(newline,0,newline.length());
		}
		out.write(introduc,0,introduc.length());
		out.close();
			}
	}

